# -*- coding: utf-8 -*-
# @Time    : 2023/8/1 10:15
# @Author  : PJH
# @File    : _init_.py.py
# @Description :

from .mywork import get_file_folder


