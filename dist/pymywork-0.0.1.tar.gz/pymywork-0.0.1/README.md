### Test-PJHpy

#### 安装

> pip install pymywork

#### version

0.0.2